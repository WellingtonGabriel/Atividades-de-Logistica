## Curriculo 🧷

Currículo responsivo feito em HTML e CSS, afim de procura de vagas de emprego.

![Curriculo-VitorBelo-1](https://user-images.githubusercontent.com/47865001/160079538-784c78de-13a2-4c5d-be85-7cb0e4f3447f.jpg)

Baixar currículo:
[Curriculo-VitorBelo.pdf](https://github.com/vitorbelo/Curriculo/files/8348554/Curriculo-VitorBelo.pdf)
